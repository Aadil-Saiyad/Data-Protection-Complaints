[comment]: <> (Centering the navbar over all pages)
<center>
<|navbar|>
</center>